//
//  LLZPrograssView.m
//  RunLoop
//
//  Created by llz on 2017/8/9.
//  Copyright © 2017年 lianai911. All rights reserved.
//

#import "LLZPrograssView.h"

@interface LLZPrograssView ()
@end
@implementation LLZPrograssView
{
    CGPoint _center;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    _center = CGPointMake(self.center.x-self.frame.origin.x, self.center.y-self.frame.origin.y);
    UIBezierPath *bezierPath = [UIBezierPath bezierPathWithArcCenter:_center radius:self.bounds.size.width/2-5 startAngle:0 endAngle:2*M_PI*self.prograss clockwise:YES];
    [[UIColor clearColor] setFill];
    [[UIColor redColor] setStroke];
    bezierPath.lineWidth = 4;
    bezierPath.lineJoinStyle = kCGLineJoinRound;
    [bezierPath fill];
    [bezierPath stroke];
}

-(void)setPrograss:(CGFloat)prograss
{
    _prograss = prograss;
    [self setNeedsDisplay];
}
@end
