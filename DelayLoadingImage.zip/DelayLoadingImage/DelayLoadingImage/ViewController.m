//
//  ViewController.m
//  RunLoop
//
//  Created by YSC on 16/11/5.
//  Copyright © 2016年 lianai911. All rights reserved.
//

#import "ViewController.h"
#import "UIImageView+WebCache.h"
#import "LLZImageView.h"
@interface ViewController ()<NSMachPortDelegate>

@property (weak, nonatomic) LLZImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    LLZImageView *imageView = [[LLZImageView alloc] init];
    self.imageView = imageView;
    self.imageView.frame = CGRectMake(55, 517, 100, 100);
    [self.view addSubview:imageView];
    [self showDemo];
   
}

/**
 * 第三个例子：用来展示UIImageView的延迟显示
 */
- (void)showDemo
{
    
    [self performSelector:@selector(setImage:) withObject:@"http://pic49.nipic.com/file/20140927/19617624_230415502002_2.jpg" afterDelay:3 inModes:@[NSDefaultRunLoopMode]];
}

-(void)setImage:(NSString *)str
{
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:str] placeholderImage:[UIImage imageNamed:@"tupian"] options:SDWebImageDelayPlaceholder|SDWebImageRetryFailed|SDWebImageCacheMemoryOnly progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
        NSLog(@"%.2f",(CGFloat)receivedSize/expectedSize);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.prograss = (CGFloat)receivedSize/expectedSize;
        });
    } completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.imageView.prograss = 0;
        });
    }];
    
    
}

- (IBAction)BtnClick:(id)sender {
    NSLog(@".....");
}


@end
