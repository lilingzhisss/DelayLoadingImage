//
//  LLZImageView.h
//  RunLoop
//
//  Created by llz on 2017/8/9.
//  Copyright © 2017年 lianai911. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLZPrograssView.h"
@interface LLZImageView : UIImageView
@property (nonatomic,assign) CGFloat prograss;
@property (nonatomic,strong) LLZPrograssView *view;
@end
