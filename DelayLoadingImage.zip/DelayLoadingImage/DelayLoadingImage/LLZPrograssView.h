//
//  LLZPrograssView.h
//  RunLoop
//
//  Created by llz on 2017/8/9.
//  Copyright © 2017年 lianai911. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLZPrograssView : UIView
@property (nonatomic,assign) CGFloat prograss;
@end
