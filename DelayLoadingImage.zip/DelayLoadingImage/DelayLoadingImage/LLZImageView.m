//
//  LLZImageView.m
//  RunLoop
//
//  Created by llz on 2017/8/9.
//  Copyright © 2017年 lianai911. All rights reserved.
//

#import "LLZImageView.h"

@implementation LLZImageView

-(void)setPrograss:(CGFloat)prograss
{
    _prograss = prograss;
    self.view.prograss = prograss;
}

-(LLZPrograssView *)view
{
    if (_view == nil) {
        _view = [[LLZPrograssView alloc] initWithFrame:self.bounds];
        _view.backgroundColor = [UIColor clearColor];
        [self addSubview:_view];
    }
    return _view;
}
@end
