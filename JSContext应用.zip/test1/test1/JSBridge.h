//
//  JSBridge.h
//  test1
//
//  Created by issuser on 2018/5/23.
//  Copyright © 2018年 issuser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
@protocol JSBridgeExport <JSExport>

//为webview中提供与native一致的提示功能
- (void)showTip:(NSString *)tip;

@end

@interface JSBridge : NSObject<JSBridgeExport>
@property (nonatomic,weak) id JSCallObject;
@end
