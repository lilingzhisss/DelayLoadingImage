//
//  JSBridge.m
//  test1
//
//  Created by issuser on 2018/5/23.
//  Copyright © 2018年 issuser. All rights reserved.
//

#import "JSBridge.h"

@implementation JSBridge
- (void)showTip:(NSString *)tip
{
    if ([_JSCallObject respondsToSelector:_cmd]) {
        [_JSCallObject showTip:tip];
    }
}

@end
