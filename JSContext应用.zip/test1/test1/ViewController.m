//
//  ViewController.m
//  test1
//
//  Created by issuser on 2018/5/17.
//  Copyright © 2018年 issuser. All rights reserved.
//

#import "ViewController.h"
#import "JSBridge.h"
@interface ViewController ()<UIWebViewDelegate,JSBridgeExport>

@property (nonatomic,weak) UIWebView *webView;
@property (nonatomic, strong) JSContext *context;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    webView.delegate = self;
    self.webView = webView;
    NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
    [self.view addSubview:webView];
    
}
//js调用oc的方法
-(void)showTip:(NSString *)tip
{
    NSLog(@"%@",tip);
}
-(void)test{
    JSValue *JSfunc =self.context[@"alert"];
    [JSfunc callWithArguments:@[@"qwdasdasdasd"]];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    self.context = [self.webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    JSBridge *jsBridge = [[JSBridge alloc] init];
    jsBridge.JSCallObject = self;
    self.context[@"jsBridge"] = jsBridge;
    self.context[@"vvvv"] = ^(NSString *str) {
        NSLog(@"%@",str);
    };
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //        [self.webView stringByEvaluatingJavaScriptFromString:@"setTimeout(function(){alert('I am an alert box!!')},100)"];
        //        [self.context evaluateScript:@"setTimeout(function(){alert('I am an alert box!!')},100)"];
        //        [self performSelectorOnMainThread:@selector(test) withObject:nil waitUntilDone:NO];
        [self.context evaluateScript:@"jsBridge.showTip(\"js调用方法showTip触发方法\")"];
        [self.context evaluateScript:@"vvvv(\"js调用vvvv方法触发block\")"];
        
    });
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
